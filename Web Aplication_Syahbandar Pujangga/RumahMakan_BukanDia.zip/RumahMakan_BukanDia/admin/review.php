<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">

<?php include "header.php"; ?>
<?php include "connect.php"; ?>
<style type="text/css">
	tr {
		font-size: 1.2em;


	}

	tr:hover {
		background-color: black;
		color: white;


	}

	th {
		color: tomato;
		font-size: 1.3em;
	}

	.del {
		color: red;
		text-decoration: none;
	}

	.del:hover {
		color: blue;
		text-decoration: none;
		text-shadow: 2px 3px 2px #FFFFFF;
	}
</style>
<div class="content">
	<table class="table table-striped">

		<tr>
			<th style="text-align: center;">NO</th>
			<th style="text-align: center;">ID</th>
			<th style="text-align: center;">NAME</th>
			<th style="text-align: center;">REVIEW</th>
			<th style="text-align: center;">COMMENTS</th>
			<th style="text-align: center;">REMOVE</th>
		</tr>
		<?php
		$no = 1;
		$s = mysqli_query($con, "select * from review");
		while ($r = mysqli_fetch_array($s)) {
		?>
			<tr align=center>
				<td><?php echo $no++ ?></td>
				<td><?php echo $r['id']; ?></td>
				<td><?php echo $r['name']; ?></td>
				<td><?php echo $r['review']; ?></td>
				<td><?php echo $r['description']; ?></td>
				<td><a href="delreview.php?a=<?php echo $r['id']; ?>" class="del">DELETE</a></td>
			</tr>
		<?php
		}
		?>


	</table>


</div>
<?php include "footer.php"; ?>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.superslides.min.js"></script>
<script src="js/images-loded.min.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/baguetteBox.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>