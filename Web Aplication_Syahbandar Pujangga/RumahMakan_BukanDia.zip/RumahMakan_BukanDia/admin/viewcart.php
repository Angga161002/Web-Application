<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">    
	<!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

<?php session_start();
if(isset($_SESSION['uid']))
{

include "header.php"; ?>
<div style="background-color: white; width: 98%; margin: 0 auto; ">
	<br>
	<?php	include "connect.php";
	$pid = $_GET['pid'];
	$uid = $_GET['uid'];
		?>

	<table border=1 align="center" width=90% cellspacing="10" cellpadding="12">
		<tr>
			<th>NO</th>
			<th>UserID</th>
			<th>Product ID</th>
			<th>Price</th>
			<th>Qty</th>
			<th>Total</th>
			<th>Image</th>
			
			
		</tr>
		<?php 

		$s = mysqli_query($con,"SELECT addcart.price, addcart.p_id, addcart.qty, addcart.total,addcart.id, pesanan.name, addcart.u_id, menu.image
FROM addcart
INNER JOIN pesanan ON addcart.p_id=pesanan.p_id INNER JOIN menu on menu.id=pesanan.p_id  where addcart.u_id='$uid' and pesanan.p_id='$pid'");


		while($r = mysqli_fetch_array($s))
		{
		?>
		<tr>
				<td><?php echo $r['id']; ?></td>
				<td><?php echo $r['u_id']; ?></td>
				<td><?php echo $r['p_id']; ?></td>
				<td><?php echo $r['price']; ?></td>
				<td><?php echo $r['qty']; ?></td>
				<td><?php echo $r['total']; ?></td>
				<td><img src="<?php echo $r['image']; ?>" width=100 height=100></td>
			
		</tr>
		<?php
			}
		?>

	</table>
</div>

<?php include "footer.php"; ?>

<?php
}
else
{
     header("location:viewcart.php");
}
?>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
	<script src="js/jquery.superslides.min.js"></script>
	<script src="js/images-loded.min.js"></script>
	<script src="js/isotope.min.js"></script>
	<script src="js/baguetteBox.min.js"></script>
	<script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
