<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">

<?php include "header.php"; ?>
<div class="row">
    <div class="co-12">


        <div class="content">
            <br><br>
            <?php include  "connect.php"; ?>
            <?php
            $a = $_GET['a'];
            mysqli_query($con, "delete from pesanan where id='$a'");

            ?>
            <table class="table table-striped ">
                <tr>
                    <th colspan="10" style="text-align:center;">PARCEL CLIENTS</th>
                </tr>
                <tr>
                    <th style="text-align:center;">Product ID</th>
                    <th style="text-align:center;">User ID</th>
                    <th style="text-align:center;">Customer Name</th>
                    <th style="text-align:center;">Mobile</th>
                    <th style="text-align:center;">Email</th>
                    <th style="text-align:center;">Address</th>
                    <th style="text-align:center;">Orders</th>
                    <th style="text-align:center;">Pay Status</th>
                    <th style="text-align:center;">View Product</th>
                    <th style="text-align:center;">Remove</th>
                </tr>
                <?php
                $s = mysqli_query($con, "select * from pesanan");
                while ($r = mysqli_fetch_array($s)) {
                ?>
                    <tr>
                        <td><?php echo $r['p_id']; ?></td>
                        <td><?php echo $r['u_id']; ?></td>
                        <td><?php echo $r['name']; ?></td>
                        <td><?php echo $r['mobile']; ?></td>
                        <td><?php echo $r['email']; ?></td>
                        <td><?php echo $r['location']; ?></td>
                        <td><?php echo $r['jenis_pesanan']; ?></td>
                        <td><?php echo $r['pay_status']; ?></td>
                        <td><a href="viewcart.php?pid=<?php echo $r['p_id']; ?>&uid=<?php echo $r['u_id']; ?>">View Product</a></td>
                        <td><a href="delparclient.php?a=<?php echo $r['id']; ?>" class="del">DELETE</a></td>
                    <?php
                }
                    ?>
            </table>


        </div>
    </div>
</div>
<?php include "footer.php"; ?>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.superslides.min.js"></script>
<script src="js/images-loded.min.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/baguetteBox.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>