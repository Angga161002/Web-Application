<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">

<?php include 'connect.php'; ?>


<!DOCTYPE html>
<html>

<head>
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body {
            padding-top: 100px;
        }
    </style>
</head>

<body>

    <center>
        <table border=1 cellpadding="6" cellspacing="8">
            <tr>
                <th colspan="10" style="font-size:2.3em; text-align:center;">Order Online Report</th>
            </tr>
            <tr>
                <th style="text-align:center;">NO</th>
                <th style="text-align:center;">ID</th>
                <th style="text-align:center;">ID Item</th>
                <th style="text-align:center;">User ID</th>
                <th style="text-align:center;">Name</th>
                <th style="text-align:center;">Phone Number</th>
                <th style="text-align:center;">Email</th>
                <th style="text-align:center;">Location</th>
                <th style="text-align:center;">Order Type</th>
                <th style="text-align:center;">Pay Status</th>
            </tr>
            <?php
            $no = 1;
            $query = mysqli_query($con, "SELECT * FROM pesanan where jenis_pesanan = 'Order Online'");
            while ($d = mysqli_fetch_assoc($query)) { ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $d['id'] ?></td>
                    <td><?php echo $d['p_id'] ?></td>
                    <td><?php echo $d['u_id'] ?></td>
                    <td><?php echo $d['name'] ?></td>
                    <td><?php echo $d['mobile'] ?></td>
                    <td><?php echo $d['email'] ?></td>
                    <td><?php echo $d['location'] ?></td>
                    <td><?php echo $d['jenis_pesanan'] ?></td>
                    <td><?php echo $d['pay_status'] ?></td>
                <?php
            }
                ?>
        </table>
    </center>
    </div>
    </div>
    <br>



    <script src="js/bootstrap.bundle.min.js"></script>





    <!-- DataTables -->
    <script type="text/javascript">
        window.print();

        function PreviewImage() {
            var oFReader = new FileReader();
            oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);


            oFReader.onload = function(oFREvent) {
                document.getElementById("uploadPreview").src = oFREvent.target.result;
            };
        };
    </script>

</body>

</html>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.superslides.min.js"></script>
<script src="js/images-loded.min.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/baguetteBox.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>