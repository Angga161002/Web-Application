<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">

<?php session_start();
include "connect.php";
$aid = $_POST['aid'];
$pass = $_POST['pass'];

$sql = mysqli_query($con, "select * from admin where adminid='$aid' and password='$pass'");
if (mysqli_fetch_array($sql)) {
	$_SESSION['aid'] = $aid;
	header("location:after_login.php");
} else { 
	echo"<script>alert('Please Enter Valid User Id and Password')</script>";
	echo"<script>location = 'index.php'</script>";

}
?>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.superslides.min.js"></script>
<script src="js/images-loded.min.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/baguetteBox.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>