<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">

<?php include "header.php"; ?>
<link rel="stylesheet" type="text/css" href="style.css">
<div class="content">
	<form action="" method="post">
		<table class="table table-striped ">
			<tr align="center">
				<td class="title">Upload New Food Category</td>
			</tr>

			<tr align="center">
				<td>
					<select class="text" name="cat">
						<option value="kathiyawadi">kathiyawadi</option>
						<option value="rajsthani">rajsthani</option>
						<option value="rise">rise</option>
						<option value="tava">tava</option>
					</select>
				</td>
			</tr>
			<tr align="center">
				<td><input type="text" name="scat" value="" placeholder="" class="text" required></td>
			</tr>
			<tr align="center">
				<td><input type="submit" name="s" value="   Upload Now   " class="btn btn-primary"></td>
			</tr>
		</table>
	</form>
	<?php
	if (isset($_POST['s'])) {
		include "connect.php";
		$cat = $_POST['cat'];
		$scat = $_POST['scat'];
		mysqli_query($con, "insert into food_cat(catnm,sub_cat) values('$cat','$scat')") or die(mysqli_error($con));
		echo "<script>alert('Category Upload SuccessFully');</script>";
		echo "<div style='color:red; font-size:1.5em; font-family:arial; text-align:center;'>Category Uploaded</div>";
	}


	?>
</div>
<?php include "footer.php"; ?>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.superslides.min.js"></script>
<script src="js/images-loded.min.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/baguetteBox.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>