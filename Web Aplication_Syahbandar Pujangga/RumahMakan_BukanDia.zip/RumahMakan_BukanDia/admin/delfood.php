<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">

<?php include "header.php"; ?>
<?php include "connect.php"; ?>
<style type="text/css">
	tr {
		font-size: 1.2em;


	}

	tr:hover {
		background-color: black;
		color: white;


	}

	th {
		color: tomato;
		font-size: 1.3em;
	}

	.del {
		color: red;
		text-decoration: none;
	}

	.del:hover {
		color: blue;
		text-decoration: none;
		text-shadow: 2px 3px 2px #FFFFFF;
	}
</style>
<div class="content">
	<?php
	$a = $_GET['a'];
	mysqli_query($con, "delete from menu where id='$a'");
	header("location:view_food.php");
	?>

</div>
<?php include "footer.php"; ?>
<!-- ALL JS FILES -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.superslides.min.js"></script>
<script src="js/images-loded.min.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/baguetteBox.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>