<?php include 'connect.php'; ?>


<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
    body{
        padding-top: 100px;
    }
    </style>
</head>
<body>

<div class="row justify-content-center">
	<div class="col-4" >

		<div class="content">
        <table class="table table-striped table-hover" border=2 >
        <tr>
                <center>
                    <th colspan="10" style="font-size:1.0em; text-align:center;">Rumah Makan Bukan Dia<br>
                    Makan Kenyang Hatipun Senang
                </th>
                </center>
            </tr>
            <tr>

                <?php 
                
                    $no = 1;
                    $query = mysqli_query($con,"SELECT * FROM addcart
                    INNER JOIN pesanan on addcart.p_id = pesanan.p_id");
                    while($d = mysqli_fetch_assoc($query)){?>

                        <tr>
                            <td>No Pesanan</td>
                            <td>:</td>
                            <td><?php echo $no++ ?></td>
                    </tr>
                    <tr>
                    <td>Id Pesanan</td>
                            <td>:</td>
                            <td><?php echo $d['p_id'] ?></td>
                            </tr>
                            <tr>
                            <td>Jenis Pesanan</td>
                            <td>:</td>
                            <td><?php echo $d['jenis_pesanan'] ?></td>
                            </tr>
                            <tr>
                            <td>Status Bayar</td>
                            <td>:</td>
                            <td><?php echo $d['pay_status'] ?></td>
                            </tr>
                            <tr>
                            <td>Harga Pesanan</td>
                            <td>:</td>
                            <td><?php echo $d['price'] ?></td>
                            </tr>
                            <tr>
                            <td>Jumlah Pesanan</td>
                            <td>:</td>
                            <td><?php echo $d['qty'] ?></td>
                            </tr>
                            <tr>
                            <td>Total Harga</td>
                            <td>:</td>
                            <td><?php echo $d['total'] ?></td>
                            </tr>
                    

                    <?php } ?>
                
            </tr>
            <tr>
                <center>
                    <th colspan="10" style="font-size:1.0em; text-align:center;">Struck Pembayaran
                </th>
                </center>
            </tr>
        </table>
    </div>
                    </div>
</div>
<br>



<script src="js/bootstrap.bundle.min.js"></script>





<!-- DataTables -->
<script type="text/javascript">
	window.print();

  function PreviewImage() {
    var oFReader = new FileReader();
    oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);


    oFReader.onload = function (oFREvent) {
      document.getElementById("uploadPreview").src = oFREvent.target.result;
    };
  };
</script>

</body>
</html>