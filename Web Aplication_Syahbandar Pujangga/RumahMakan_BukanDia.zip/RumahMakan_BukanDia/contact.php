<?php include "header.php"; ?>	
	<!-- Start All Pages -->
		
		<img src="images/cn.png" width="100%">
	<!-- End All Pages -->
	
	<!-- Start Contact -->
	<div>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.299349626902!2d100.44057401416886!3d-0.9241387993258509!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2fd4b78125fe9765%3A0xb4176d42790c0d03!2sAmpera%20BUKAN%20DIA!5e0!3m2!1sid!2sid!4v1638371749982!5m2!1sid!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

	</div>
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Contact</h2>
						<p>Contact Information are Listed here Thanks for Visit Our Site</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<form id="contactForm">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<h1 style="font-family: cambria; color: red; text-align: center;">Rumah Makan Bukan Dia</h1>
									<div class="help-block with-errors"></div>
								</div>                                 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Email Us :</b> BukanDia@gmail.com</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Mobile  :</b> +62 813 7228 1810</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group"> 
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Location  :</b> Jl. Dr. Moh. Hatta kecamatan No.90, Kapala Koto, Kec. Pauh, Kota Padang</span></center>
									<div class="help-block with-errors"></div>
								</div>
								
							</div>
						</div>            
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End Contact -->
<?php include "footer.php"; ?>